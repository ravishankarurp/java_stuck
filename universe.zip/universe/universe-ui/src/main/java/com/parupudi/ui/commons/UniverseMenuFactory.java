package com.parupudi.ui.commons;

import com.parupudi.navigator.UniverseNavigator;
import com.parupudi.utils.StringUtils;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.ui.Component;
import com.vaadin.ui.Tree;
import com.vaadin.ui.VerticalLayout;

@org.springframework.stereotype.Component
public class UniverseMenuFactory implements UIComponentBuilder {

	@SuppressWarnings("serial")
	private class UniverseMenu extends VerticalLayout implements Property.ValueChangeListener{
	
		private Tree mainMenu;
		public UniverseMenu init() {
			mainMenu = new Tree();
			mainMenu.addValueChangeListener(this);
			return this;
		}
		public UniverseMenu layout() {
			setWidth("100%");
			setHeightUndefined();
			
			// To reference StringUtils.*, we have added universe-utils as a dependency on the universe-ui module.
			mainMenu.addItem(StringUtils.MENU_STUDENT.getString());
			mainMenu.addItem(StringUtils.MENU_UNIVERSITY.getString());
			
			mainMenu.expandItem(StringUtils.MENU_STUDENT.getString());
			mainMenu.expandItem(StringUtils.MENU_UNIVERSITY.getString());
			
			mainMenu.addItem(StringUtils.MENU_ADD_STUDENT.getString());
			mainMenu.addItem(StringUtils.MENU_REMOVE_STUDENT.getString());
			mainMenu.setChildrenAllowed(StringUtils.MENU_ADD_STUDENT.getString(), false);
			mainMenu.setChildrenAllowed(StringUtils.MENU_REMOVE_STUDENT.getString(), false);
			mainMenu.setParent(StringUtils.MENU_ADD_STUDENT.getString(),StringUtils.MENU_STUDENT.getString());
			mainMenu.setParent(StringUtils.MENU_REMOVE_STUDENT.getString(),StringUtils.MENU_STUDENT.getString());
			
			mainMenu.addItem(StringUtils.MENU_OPERATIONS.getString());
			mainMenu.setChildrenAllowed(StringUtils.MENU_OPERATIONS.getString(), false);
			mainMenu.setParent(StringUtils.MENU_OPERATIONS.getString(),StringUtils.MENU_UNIVERSITY.getString());
			
			addComponent(mainMenu);
			
			return this;
		}
		public void valueChange(ValueChangeEvent event) {
			// On every menu click, this gets called because this private class implements the value change listener
			String selectedItemPath = (String)event.getProperty().getValue();

			if (selectedItemPath == null) return;
			
			// View to navigate to will be selectedItemPath, stripped of spaces and converted to lower case. Add Student --> addstudent
			String path = selectedItemPath.toLowerCase().replaceAll("\\s+", "");
			
			UniverseNavigator.navigate(path);
		}
	}
	
	public Component createComponent() {
		return new UniverseMenu().init().layout();
	}

}
