package com.parupudi.ui.commons;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.parupudi.navigator.UniverseNavigator;
import com.parupudi.ui.students.StudentLayoutFactory;
import com.vaadin.annotations.Theme;
import com.vaadin.annotations.Title;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.spring.navigator.SpringViewProvider;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Component;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Panel;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;

@SuppressWarnings("serial")
@SpringUI(path=UniverseMainUI.NAME)
@Title("Universe Application")
@Theme("valo")
public class UniverseMainUI extends UI{
	
	public static final String NAME = "/ui"; // used in @SpringUI
	
	private Panel changeTab = new Panel();
	
	@Autowired
	private UniverseLogoLayoutFactory universeLogoLayoutFactory; // auto wired so no further instances of this are to be explicitly created
	@Autowired
	private UniverseMenuFactory universeMenuFactory;
	
	@Autowired
	private ApplicationContext applicationContext; // Every class that has the component or service or repository annotation is going to be injected into the application context. 
	
	@Autowired
	private SpringViewProvider springViewProvider; // This will include all classes which are annotated with SpringView annotation and inject them into sprring view provider. 
	
	@Override
	protected void init(VaadinRequest request) {
		
		changeTab.setHeight("100%");
		
		VerticalLayout rootLayout = new VerticalLayout();
		rootLayout.setSizeFull();
		rootLayout.setMargin(true);

		Panel contentPanel = new Panel();
		contentPanel.setWidth("75%");
		contentPanel.setHeight("100%");

		Panel logoPanel = new Panel();
		logoPanel.setWidth("75%");
		logoPanel.setHeightUndefined(); // as small as possible
		
		HorizontalLayout uiLayout = new HorizontalLayout();
		uiLayout.setSizeFull();
		uiLayout.setMargin(true);
		
//		Component logo
		Component logo = universeLogoLayoutFactory.createComponent(); // we can do this as this component is auto-wired!
//		Component menu
		Component menu = universeMenuFactory.createComponent();
		
		uiLayout.addComponent(menu);
		uiLayout.addComponent(changeTab);
		
		uiLayout.setComponentAlignment(changeTab, Alignment.TOP_CENTER);
		uiLayout.setComponentAlignment(menu, Alignment.TOP_CENTER);
		
		uiLayout.setExpandRatio(menu, 1);
		uiLayout.setExpandRatio(changeTab, 2);
		
		logoPanel.setContent(logo);
		contentPanel.setContent(uiLayout);
		
		rootLayout.addComponent(logoPanel);
		rootLayout.addComponent(contentPanel);
		rootLayout.setComponentAlignment(contentPanel, Alignment.MIDDLE_CENTER);
		rootLayout.setComponentAlignment(logoPanel, Alignment.TOP_CENTER);
		rootLayout.setExpandRatio(contentPanel, 1);
		
		initNavigator();
		
		setContent(rootLayout);
		
	}


	private void initNavigator() {
		// UniverseNavigator isn't declared as a component class, so must be manually instantiated.
		UniverseNavigator navigator = new UniverseNavigator(this, changeTab);
		applicationContext.getAutowireCapableBeanFactory().autowireBean(navigator); // This is manually injecting the navigator into the application context
		navigator.addProvider(springViewProvider); // This will inject all classes which have @SpringView annotation into this navigator automatically. Doing this means that we don't have to individually add each and every view created for this application.
		navigator.navigateTo(StudentLayoutFactory.NAME);
		
	}

}
