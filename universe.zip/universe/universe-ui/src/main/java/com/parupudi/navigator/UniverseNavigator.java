package com.parupudi.navigator;

import com.google.gwt.thirdparty.guava.common.base.Strings;
import com.vaadin.navigator.Navigator;
import com.vaadin.ui.SingleComponentContainer;
import com.vaadin.ui.UI;

// Note that there is not Component annotation on this navigator, so this MUST be instantiated.
public class UniverseNavigator extends Navigator {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6340696690036601019L;

	public UniverseNavigator(UI ui, SingleComponentContainer container) {
		super(ui, container);
	}

	private static UniverseNavigator getNavigator() {
		UI ui = UI.getCurrent();
		Navigator navigator = ui.getNavigator();
		return (UniverseNavigator)navigator;
	}
	
	public static void navigate(String path) {
		try {
			UniverseNavigator.getNavigator().navigateTo(path);
		}
		catch(Exception e) {
			return;
		}
	}

	@Override
	public void navigateTo(String viewName) {
		super.navigateTo(Strings.nullToEmpty(viewName));
	}
	
	
	
}
