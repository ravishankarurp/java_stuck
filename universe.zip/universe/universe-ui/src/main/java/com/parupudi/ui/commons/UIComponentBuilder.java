package com.parupudi.ui.commons;

import com.vaadin.ui.Component;

public interface UIComponentBuilder {
	public Component createComponent();
}
