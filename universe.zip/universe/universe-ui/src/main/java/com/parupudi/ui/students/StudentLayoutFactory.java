package com.parupudi.ui.students;

import org.springframework.beans.factory.annotation.Autowired;

import com.parupudi.ui.commons.UniverseMainUI;
import com.parupudi.utils.StudentStringUtils;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.Component;
import com.vaadin.ui.Label;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.VerticalLayout;

@SuppressWarnings("serial")
@SpringView(name=StudentLayoutFactory.NAME, ui=UniverseMainUI.class)
public class StudentLayoutFactory extends VerticalLayout implements View {
	
	public static final String NAME = "addstudent";
	
	private TabSheet tabSheet;
	
	@Autowired
	private AddStudentMainLayoutFactory addStudentMainLayoutFactory;

	public void enter(ViewChangeEvent event) {
		removeAllComponents();
		addLayout();
	}

	private void addLayout() {
		setMargin(true);
		tabSheet = new TabSheet();
		tabSheet.setWidth("100%");
		
		Component addStudentMainTab = addStudentMainLayoutFactory.createComponent();
		Component showStudentsTab = new Label("Show students tab Content...");
		
		tabSheet.addTab(addStudentMainTab, StudentStringUtils.MAIN_MENU.getString());
		tabSheet.addTab(showStudentsTab, StudentStringUtils.SHOW_ALL_STUDENTS.getString());
		
		addComponent(tabSheet);
		
	}
	
	
}
