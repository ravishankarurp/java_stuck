package com.parupudi.ui.students;

import com.parupudi.model.entity.Student;
import com.parupudi.utils.Gender;
import com.parupudi.utils.NotificationMessages;
import com.parupudi.utils.StudentStringUtils;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup.CommitException;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.GridLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@org.springframework.stereotype.Component // So this can be injected into the StudentLayoutFactory as a dependency
public class AddStudentMainLayoutFactory {

	// Builder pattern
	@SuppressWarnings("serial")
	// implements Button.ClickListener so that Save and Clear buttons can be handled
	// within the private class
	// so basically saveButton.addClickListener(this) and the click event triggers
	// the buttonClick method of this private class
	private class AddStudentMainLayout extends VerticalLayout implements Button.ClickListener {

		private TextField firstName;
		private TextField lastName;
		private TextField age;
		private ComboBox gender;
		private Button saveButton;
		private Button clearButton;

		private BeanFieldGroup<Student> fieldGroup; // Need to import universe-model into universe-ui module to support
													// this.
		private Student student; // Need to import universe-model into universe-ui module to support this.

		public AddStudentMainLayout init() {

			fieldGroup = new BeanFieldGroup<Student>(Student.class);
			student = new Student();

			firstName = new TextField(StudentStringUtils.FIRST_NAME.getString());
			lastName = new TextField(StudentStringUtils.LAST_NAME.getString());
			age = new TextField(StudentStringUtils.AGE.getString());
			gender = new ComboBox(StudentStringUtils.GENDER.getString());

			saveButton = new Button(StudentStringUtils.SAVE_BUTTON.getString());
			clearButton = new Button(StudentStringUtils.CLEAR_BUTTON.getString());

			saveButton.setStyleName(ValoTheme.BUTTON_FRIENDLY);
			clearButton.setStyleName(ValoTheme.BUTTON_PRIMARY);

			saveButton.addClickListener(this);
			clearButton.addClickListener(this);

			firstName.setNullRepresentation(""); // This representation means the fields don't show up as 'null' when
													// form loads
			lastName.setNullRepresentation("");
			age.setNullRepresentation("");

			gender.addItem(Gender.MALE.getString());
			gender.addItem(Gender.FEMALE.getString());

			return this;
		}

		public AddStudentMainLayout bind() {

			fieldGroup.bindMemberFields(this); // instead of one-by-one, this is in bulk. This will work as long as the
												// TextField name is EXACTLY the same as the model Student's variables
												// If the names are not the same, we would use the @PropertyId
												// annotation to bind the TextField to the model components
			fieldGroup.setItemDataSource(student);
			return this;
		}

		public Component layout() {

			setMargin(true);
			GridLayout gridLayout = new GridLayout(2, 4); // 2 Columns and 4 rows
			gridLayout.setSizeUndefined();
			gridLayout.setSpacing(true);
			gridLayout.addComponent(firstName, 0, 0); // Row 1, Column 1
			gridLayout.addComponent(lastName, 1, 0); // Row 1, Column 2
			gridLayout.addComponent(age, 0, 1); // Row 2
			gridLayout.addComponent(gender, 0, 2); // Row 3

			gridLayout.addComponent(new HorizontalLayout(saveButton, clearButton), 0, 3);

			return gridLayout;
		}

		public void buttonClick(ClickEvent event) {
			if (event.getSource() == this.saveButton) {
				save();
			} else {
				clearFields();
			}
		}

		private void save() {
			try {
				fieldGroup.commit(); // Commit TextField or Form content to the Student object
			} catch (CommitException e) {
				Notification.show(NotificationMessages.STUDENT_SAVE_VALIDATION_ERROR_TITLE.getString(),
						NotificationMessages.STUDENT_SAVE_VALIDATION_ERROR_DESC.getString(), Type.ERROR_MESSAGE);
				return;
			}
			
			clearFields();
			
			Notification.show(NotificationMessages.STUDENT_SAVE_VALIDATION_SUCCESS_TITLE.getString(),
					NotificationMessages.STUDENT_SAVE_VALIDATION_SUCCESS_DESC.getString(), Type.HUMANIZED_MESSAGE);
			
			System.out.println(student);
		}

		private void clearFields() {
			firstName.setValue(null);
			lastName.setValue(null);
			gender.setValue(null);
			age.setValue(null);
		}

	}

	public Component createComponent() {
		// No UIComponentBuilder interface defined for this method (like done in
		// MenuFactory or LogoFactory, as we are supposed to have an event listener as a
		// parameter.
		return new AddStudentMainLayout().init().bind().layout();
	}

}
