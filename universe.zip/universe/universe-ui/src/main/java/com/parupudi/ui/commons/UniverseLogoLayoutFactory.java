package com.parupudi.ui.commons;

import com.vaadin.server.ThemeResource;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Component;
import com.vaadin.ui.Embedded;
import com.vaadin.ui.VerticalLayout;

@org.springframework.stereotype.Component
public class UniverseLogoLayoutFactory implements UIComponentBuilder{

	// This is called a builder pattern to return a logo layout when createComponent is called
	private class LogoLayout extends VerticalLayout{
		/**
		 * Generated to keep warnings away
		 */
		private static final long serialVersionUID = 5717432152330725912L;
		
		private Embedded logo;
		public LogoLayout init() {
			
			logo = new Embedded();
			logo.setSource(new ThemeResource("../../images/universe.png"));
			logo.setWidth("350px");
			logo.setHeight("242px");
			
			return this;
		}
		
		public LogoLayout layout() {
			addComponent(logo);
			setComponentAlignment(logo,  Alignment.MIDDLE_CENTER);
			return this;
		}
	}
	
	public Component createComponent() {
		// TODO Auto-generated method stub
		return new LogoLayout().init().layout();
	}

}
