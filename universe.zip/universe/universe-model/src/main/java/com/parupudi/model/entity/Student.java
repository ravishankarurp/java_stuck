package com.parupudi.model.entity;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class Student {

	private Integer id; // don't use INT for data binding
	@NotNull(message = "First Name must be provided") // add JAVAX-validation dependency to this project to get this
														// annotation working.
	private String firstName;
	@NotNull(message = "Last Name must be provided")
	private String lastName;
	@NotNull(message = "Age must be provided")
	@Min(value = 0, message = "Min age is 0")
	@Max(value = 100, message = "Max age is 100")
	private Integer age;
	private String gender;

	public Student() {
	}

	@Override
	public String toString() {
		return "STUDENT: " + firstName + " " + lastName + " " + gender + " " + age + " (" + id + ")";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

}
