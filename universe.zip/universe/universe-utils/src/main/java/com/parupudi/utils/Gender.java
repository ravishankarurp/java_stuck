package com.parupudi.utils;

public enum Gender {

	MALE("Male"),
	FEMALE("Female");
	
	private final String string;
	
	private Gender(String string) {
		this.string = string;
	}
	
	public String getString() {
		return this.string;
	}
}
