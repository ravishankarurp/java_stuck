package com.parupudi.utils;

public enum NotificationMessages {
	STUDENT_SAVE_VALIDATION_ERROR_TITLE("There was an issue with validation."),
	STUDENT_SAVE_VALIDATION_ERROR_DESC("Some description"),
	STUDENT_SAVE_VALIDATION_SUCCESS_TITLE("Student saved."),
	STUDENT_SAVE_VALIDATION_SUCCESS_DESC("Some description"),
	FIRST_NAME("First Name"),
	LAST_NAME("Last Name"),
	GENDER("Gender"),
	AGE("Age"),
	SAVE_BUTTON("Save"),
	CLEAR_BUTTON("Clear");
	
	private final String string;
	
	private NotificationMessages(String string) {
		this.string = string;
	}
	
	public String getString() {
		return this.string;
	}
}
