package com.parupudi.launcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


// THIS CLASS IS GOING TO CONTAIN ALL THE IMPORTANT ANNOTATIONS REQUIRED TO CONFIGURE A SPRING BOOT APPLICATION
@Configuration
@EnableAutoConfiguration
@ComponentScan({"com.parupudi"}) // Inject all packages that start with com.parupudi within all of the application context (utils, ui, etc)
@EnableJpaRepositories({"com.parupudi"}) // This enables JPA repositories for all packages starting with com.parupudi
@EntityScan({"com.parupudi"})
public class SpringBootApplication extends 
SpringBootServletInitializer{

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(SpringBootApplication.class);
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpringBootApplication.class, args);
	}

	
}
